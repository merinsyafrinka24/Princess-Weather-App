package com.example.martinruiz.myapplication.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.example.martinruiz.myapplication.R;

public class menuawal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menuawal);
    }
    public void btnmasuk(View view) {
        Intent i1= new Intent(getApplicationContext(),listview.class);
        startActivity(i1);
    }
    public void btnnotif(View view) {
        Intent i1= new Intent(getApplicationContext(),Notifikasi.class);
        startActivity(i1);
    }
}
