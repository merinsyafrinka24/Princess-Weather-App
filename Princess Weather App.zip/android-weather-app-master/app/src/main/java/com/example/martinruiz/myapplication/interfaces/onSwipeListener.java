package com.example.martinruiz.myapplication.interfaces;

/**
 * Created by MartinRuiz on 8/20/2017.
 */

public interface onSwipeListener {
    void onItemDelete(int position);
}
